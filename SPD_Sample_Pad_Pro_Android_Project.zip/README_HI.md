# SPD Sample Pad Pro — Android Prototype

यह पहला working prototype है।

## क्या करता है
- 8 on-screen pads
- WAV/MP3/audio file import
- प्रत्येक pad पर अलग sample
- tap करके sample playback
- long press करके नया sample load
- Android MIDI device scan
- MIDI Note से pad trigger करने की शुरुआती व्यवस्था

## SPD-20 PRO / SPD-20X
फोन को सीधे 3.5mm audio cable से जोड़कर MIDI नहीं मिलेगा। सामान्य setup:

SPD-20 → MIDI/USB MIDI interface → USB OTG/USB-C → Android phone

फोन और interface compatible होना जरूरी है।

## MIDI mapping
प्रारंभिक mapping:
Pad 1–8 = MIDI notes 36, 38, 40, 41, 43, 45, 47, 49

ध्यान दें: आपके वास्तविक SPD-20 PRO / SPD-20X की pad-note assignment के अनुसार mapping बदलनी पड़ सकती है।

## APK
यह source project APK बनाने के लिए Android Studio में खोलें:
Build → Build APK(s)

यह prototype है; production version में:
- proper in-app recorder
- waveform editor
- trim/fade
- pitch/volume controls
- kit save/load
- editable MIDI mapping
- low-latency audio engine
- background audio
जोड़ना चाहिए।
