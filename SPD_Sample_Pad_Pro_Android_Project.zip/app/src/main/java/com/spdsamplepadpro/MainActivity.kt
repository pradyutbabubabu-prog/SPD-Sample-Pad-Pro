package com.spdsamplepadpro

import android.content.Intent
import android.media.AudioAttributes
import android.media.SoundPool
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiReceiver
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var soundPool: SoundPool
    private lateinit var midiManager: MidiManager
    private val sampleIds = IntArray(8) { 0 }
    private val sampleNames = Array(8) { "Empty" }
    private var selectedPad = 0
    private var midiDevice: MidiDevice? = null
    private var midiReceiver: MidiReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        soundPool = SoundPool.Builder()
            .setMaxStreams(8)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            ).build()

        midiManager = getSystemService(MIDI_SERVICE) as MidiManager
        buildUi()
    }

    private fun buildUi() {
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(0xFF101114.toInt())
        }

        val title = TextView(this).apply {
            text = "🥁 SPD SAMPLE PAD PRO"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        main.addView(title, LinearLayout.LayoutParams(-1, 60))

        val status = TextView(this).apply {
            text = "Pad 1 selected • MIDI: checking..."
            setTextColor(0xFFBFC3CA.toInt())
            gravity = Gravity.CENTER
        }
        main.addView(status, LinearLayout.LayoutParams(-1, 45))

        val grid = GridLayout(this).apply {
            columnCount = 2
            rowCount = 4
            useDefaultMargins = true
        }

        for (i in 0 until 8) {
            val b = Button(this).apply {
                text = "PAD ${i + 1}\n${sampleNames[i]}"
                textSize = 16f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundResource(com.spdsamplepadpro.R.drawable.pad_bg)
                setOnClickListener {
                    selectedPad = i
                    status.text = "Pad ${i+1} selected • ${sampleNames[i]}"
                    playPad(i)
                }
                setOnLongClickListener {
                    selectedPad = i
                    chooseAudioFile(i)
                    true
                }
                setOnTouchListener { v, e ->
                    if (e.action == MotionEvent.ACTION_DOWN) {
                        v.setBackgroundResource(R.drawable.pad_pressed)
                    } else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
                        v.setBackgroundResource(R.drawable.pad_bg)
                    }
                    false
                }
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(i % 2, 1f)
                rowSpec = GridLayout.spec(i / 2, 1f)
                setMargins(6, 6, 6, 6)
            })
        }
        main.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        val info = TextView(this).apply {
            text = "Tap = play • Long press = load WAV/MP3"
            setTextColor(0xFFBFC3CA.toInt())
            gravity = Gravity.CENTER
        }
        main.addView(info, LinearLayout.LayoutParams(-1, 45))

        val midi = Button(this).apply {
            text = "🎛️ CONNECT USB-MIDI / SCAN"
            setOnClickListener { scanMidi(status) }
        }
        main.addView(midi, LinearLayout.LayoutParams(-1, 55))

        val record = Button(this).apply {
            text = "🎤 RECORD SAMPLE (Android Recorder)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
                Toast.makeText(this@MainActivity,
                    "अपने फोन का Recorder खोलकर WAV/MP3 रिकॉर्ड करें, फिर Pad को long-press करके file चुनें.",
                    Toast.LENGTH_LONG).show()
            }
        }
        main.addView(record, LinearLayout.LayoutParams(-1, 55))

        setContentView(main)
    }

    private fun chooseAudioFile(pad: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "audio/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        selectedPad = pad
        startActivityForResult(intent, 1000 + pad)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val pad = requestCode - 1000
        val uri = data.data!!
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val outFile = File(filesDir, "pad_${pad}.audio")
                FileOutputStream(outFile).use { output -> input.copyTo(output) }
                sampleIds[pad] = soundPool.load(outFile.absolutePath, 1)
                sampleNames[pad] = uri.lastPathSegment ?: "Sample"
                Toast.makeText(this, "Pad ${pad+1} sample loaded", Toast.LENGTH_SHORT).show()
                buildUi()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Sample load failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun playPad(pad: Int) {
        if (sampleIds[pad] != 0) {
            soundPool.play(sampleIds[pad], 1f, 1f, 1, 0, 1f)
        } else {
            Toast.makeText(this, "Pad ${pad+1} खाली है. Long press करके sample load करें.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scanMidi(status: TextView) {
        val infos = midiManager.devices
        if (infos.isEmpty()) {
            status.text = "MIDI device नहीं मिला • USB OTG + USB-MIDI interface लगाएँ"
            return
        }
        val info = infos.first()
        status.text = "MIDI device मिला: ${info.properties[MidiDeviceInfo.PROPERTY_NAME] ?: "USB MIDI"}"
        midiManager.openDevice(info, { device ->
            midiDevice = device
            attachMidiInput(device, status)
        }, null)
    }

    private fun attachMidiInput(device: MidiDevice, status: TextView) {
        val input = device.inputPortCount
        val output = device.outputPortCount
        status.text = "MIDI connected • IN:$input OUT:$output"
        if (output <= 0) return

        val port = device.openOutputPort(0) ?: return
        midiReceiver = object : MidiReceiver() {
            override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                if (count >= 3) {
                    val statusByte = msg[offset].toInt() and 0xFF
                    val command = statusByte and 0xF0
                    val note = msg[offset + 1].toInt() and 0x7F
                    val velocity = msg[offset + 2].toInt() and 0x7F
                    if (command == 0x90 && velocity > 0) {
                        val pad = noteToPad(note)
                        if (pad >= 0) runOnUiThread { playPad(pad) }
                    }
                }
            }
        }
        port.connect(midiReceiver)
    }

    private fun noteToPad(note: Int): Int {
        // Default starter mapping. Can be customized in a later version.
        val map = intArrayOf(36, 38, 40, 41, 43, 45, 47, 49)
        return map.indexOf(note)
    }

    override fun onDestroy() {
        midiReceiver?.let { /* connection released with device */ }
        midiDevice?.close()
        soundPool.release()
        super.onDestroy()
    }
}
